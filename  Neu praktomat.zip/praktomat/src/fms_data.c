#include "fms.h"
#include <stdlib.h>
#include <stdio.h>

FMS* initialize(void){
//FMS *pFMS = malloc(sizeof(FMS));

static Coordinate HAMLatitude ={
    53,37,49
};
static Coordinate HAMLongtitude ={
    9,59,18
};

static Coordinate CGNLatitude ={
    50,51,57
};
static Coordinate CGNLongtitude ={
    7,8,34 
};

static Coordinate DUSLatitude ={
    51,16,51
};
static Coordinate DUSLongtitude ={
    6,45,26
};

static Coordinate FRALatitude ={
    50,1,59
};
static Coordinate FRALongtitude ={
    8,34,14
};

static Coordinate BERLatitude ={
    52,21,44
};
static Coordinate BERLongtitude ={
    13,30,2
};

static Coordinate MUCLatitude ={
    48,21,14
};
static Coordinate MUCLongtitude ={
    11,47,10
};

static Coordinate STRLatitude ={
    48,41,23.56
};
static Coordinate STRLongtitude ={
    9,13,19.07
};



static Time t0300 ={
    3,0
};
static Time t0415 ={
    4,15
};
static Time t0800 ={
    8,0
};
static Time t1000 ={
    10,0
};
static Time t1012 ={
    10,12
};
static Time t1015 ={
    10,15
};
static Time t1130 ={
    11,30
};
static Time t1300 ={
    13,0
};
static Time t1310 ={
    13,10
};
static Time t1315 ={
    14,15
};
static Time t1430 ={
    14,30
};
static Time t1500 ={
    15,0
};
static Time t1512 ={
    15,12
};
static Time t1530 ={
    15,30
};
static Time t1630 ={
    16,30
};
static Time t1700 ={
    17,0
};
static Time t1800 ={
    18,0
};
static Time t1830 ={
    18,30
};
static Time t2030 ={
    20,30
};
static Time t2045 ={
    20,45
};
static Time t2145 ={
    21,45
};
static Time t2200 ={
    22,0
};
static Time t2230 ={
    22,30
};
static Time t2330 ={
    23,30
};
static Time t2400 ={
    24,0
};



static Airport HAM ={
    "EDDH",
    "HAM",
    &HAMLatitude,
    &HAMLongtitude,
    5
};
static Airport CGN ={
    "EDDK",
    "CGN",
    &CGNLatitude,
    &CGNLongtitude,
    5
};
static Airport DUS ={
    "EDDL",
    "DUS",
    &DUSLatitude,
    &DUSLongtitude,
    5
};
static Airport FRA ={
    "EDDF",
    "FRA",
    &FRALatitude,
    &FRALongtitude,
    5
};
static Airport BER ={
    "EDDB",
    "BER",
    &BERLatitude,
    &BERLongtitude,
    5
};
static Airport MUC ={
    "EDDM",
    "MUC",
    &MUCLatitude,
    &MUCLongtitude,
    5
};
static Airport STR ={
    "EDDS",
    "STR",
    &STRLatitude,
    &STRLongtitude,
    5
};



static FlightPath LHOne ={
    "LH 2147",
    &MUC,
    &HAM,
    &t1130,
    &t1430
};
static FlightPath LHTwo ={
    "LH 2147",
    &HAM,
    &FRA,
    &t1530,
    &t1630
};
static FlightPath LHThree ={
    "LH 2147",
    &FRA,
    &MUC,
    &t1830,
    &t2030
};
static FlightPath LHFour ={
    "LH 2147",
    &MUC,
    &HAM,
    &t2045,
    &t2200
};
static FlightPath LHFive ={
    "LH 2147",
    &HAM,
    &MUC,
    &t2230,
    &t2330
};

static FlightPath EWOne ={
    "EW 2147",
    &MUC,
    &DUS,
    &t0300,
    &t0415
};
static FlightPath EWTwo ={
    "EW 2147",
    &DUS,
    &BER,
    &t0800,
    &t1000
};
static FlightPath EWThree ={
    "EW 2147",
    &BER,
    &CGN,
    &t1012,
    &t1315
};
static FlightPath EWFour ={
    "EW 2147",
    &CGN,
    &MUC,
    &t1800,
    &t2030
};
static FlightPath EWFive ={
    "EW 2147",
    &MUC,
    &DUS,
    &t2145,
    &t2330
};

static FlightPath TUIOne ={
    "X3 2174",
    &HAM,
    &STR,
    &t0800,
    &t1000
};
static FlightPath TUITwo ={
    "X3 2174",
    &STR,
    &BER,
    &t1015,
    &t1300
};
static FlightPath TUIThree ={
    "X3 2174",
    &BER,
    &FRA,
    &t1310,
    &t1500
};
static FlightPath TUIFour ={
    "X3 2174",
    &FRA,
    &HAM,
    &t1512,
    &t1700
};
static FlightPath TUIFive ={
    "X3 2174",
    &HAM,
    &FRA,
    &t2200,
    &t2400
};



static Airplane LHA380 ={
    "A380",
    "D-AIMA",
    .ptrFlightPaths = {&LHOne, &LHTwo, &LHThree, &LHFour, &LHFive},
    5
};

static Airplane EWA320 ={
    "A320",
    "D-AIAB",
    .ptrFlightPaths = {&EWOne, &EWTwo, &EWThree, &EWFour, &EWFive},
    5
};
static Airplane TUIB747 ={
    "B747",
    "D-ABCD",
    .ptrFlightPaths = {&TUIOne, &TUITwo, &TUIThree, &TUIFour, &TUIFive},
    5
};



static Airline LUFTHANSA ={
    "Lufthansa\0",
    .ptrAirplanes = {&LHA380},
    1
};
static Airline EUROWINGS ={
    "Eurowings\0",
    .ptrAirplanes = {&EWA320},
    1
};
static Airline TUIFLY ={
    "TUIFly\0",
    .ptrAirplanes = {&TUIB747},
    1
};



static FMS fms = {
    .ptrAirlines = {&LUFTHANSA, &EUROWINGS, &TUIFLY},
    3
};

return &fms;
}